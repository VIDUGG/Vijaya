<?php include("header.php");?>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Main Banner Area Start ***** -->
    <div class="page-heading" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-content">
                        <h2>Shoe Store</h2>
                        <span>A COMPLETE ONE STOP SOLUTION</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->


    <!-- ***** Products Area Starts ***** -->
    <section class="section" id="products">
      
        <div class="container">
            <div class="row">
                <div class="col-lg-12">

<?php 
//if(isset($_POST['test'])) 
//	if(isset($_GET['number']))
{

    
    
    
    $id =$_GET['number'];
$pname =$_GET['name'];
$amount =$_GET['amount'];
$pdo = require_once 'config.php';
$sql= 'INSERT INTO tblcart(name,amount) VALUES(?,?)';

$statement = $link->prepare($sql);
$statement->execute(array($pname,$amount));
echo "<h1>Item Added to cart successfully</h1>";

}
?>

<b><a href="cart.php">Continue to Cart</a></b>
                </div>
               
               
				
				
				
                
                </div>
               
            </div>
        </div>
    </section>
    <!-- ***** Products Area Ends ***** -->
    
    <!-- ***** Footer Start ***** -->
    <?php include("footer.php");?>