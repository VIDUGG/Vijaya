<form action="https://www.paypal.com/cgi-bin/webscr" method="post"> 
<input type="hidden" name="cmd" value="_xclick"> 
<input type="hidden" name="business" value="seller@designerfotos.com">
 <input type="hidden" name="item_name" value="Memorex 256MB Memory Stick"> 
 <input type="hidden" name="item_number" value="MEM32507725"> 
 <input type="hidden" name="amount" value="3"> 
 <input type="hidden" name="tax" value="1"> 
 <input type="hidden" name="quantity" value="1"> 
 <input type="hidden" name="currency_code" value="USD"> 
 <!-- Enable override of buyers's address stored with PayPal . --> 
 <input type="hidden" name="address_override" value="1"> 
 <!-- Set variables that override the address stored with PayPal. --> 
 <input type="text" name="first_name" value="John"> 
 <input type="text" name="last_name" value="Doe"> 
 <input type="text" name="address1" value="345 Lark Ave"> 
 <input type="text" name="city" value="San Jose"> 
 <input type="text" name="state" value="CA"> 
 <input type="text" name="zip" value="95121"> 
 <input type="text" name="country" value="US"> 
 <input type="image" name="submit" src="https://www.paypalobjects.com/en_US/i/btn/btn_buynow_LG.gif" alt="PayPal - The safer, easier way to pay online"> 
 </form>