<?php include("header.php");?>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Main Banner Area Start ***** -->
    <div class="page-heading" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-content">
                        <h2>Shoe Store</h2>
                        <span>A COMPLETE ONE STOP SOLUTION</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->


    <!-- ***** Products Area Starts ***** -->
    <section class="section" id="products">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-heading">
                        <h2>Cart</h2>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <form method="post" action="cart.php">
                        <input type="submit" value="Refresh">
                    </form>
       <table style="width:100%" border="2" cellpadding="10" cellspacing="10">
<tr>
<th>S.No</th>
<th>Product Name</th>
<th>Price</th>	 
  
</tr>
<?php 

	
 
$pdo = require_once('config.php');
$i=0;
$total=0;
$stmt = $link->query("SELECT * FROM tblcart");
while ($row = $stmt->fetch()) {
    $i++;
   $name = $row['name'];
$amount = $row['amount'];
$id = $row['id'];

echo"


<tr>
                 <td>$i</td>
                    <td>$name</td>    
                    
                    <td>
                      $ $amount
                    </td>
					
					
                  </tr>
                  





";
$total=$total+$amount;

}
echo "<Tr><td></td><td>Total</td>";
echo "<td>$".$total."</td>";

?>
</table>
<form action="delete.php" method="post">
<input type="submit" value="Empty Cart" name="empty">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<b><a href="index.php">Continue Shopping</a></b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
<b><a href="buynow.php?amount=<?php echo $total;?>"><input type="button" value="Pay Now"></input></a></b>
</form>
                </div>
               
               
				
				
				
                
                </div>
               
            </div>
        </div>
    </section>
    <!-- ***** Products Area Ends ***** -->
    
    <!-- ***** Footer Start ***** -->
    <?php include("footer.php");?>