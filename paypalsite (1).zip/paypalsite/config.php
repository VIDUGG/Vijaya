<?php
$dbhost = "localhost";
$dbname = "ospmiy9u_paypalsite";
$dbusername = "ospmiy9u_paypalsite";
$dbpassword = "ospmiy9u_paypalsite";
$link = new PDO("mysql:host=$dbhost;dbname=$dbname", $dbusername, $dbpassword);
$link->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$con=mysqli_connect($dbhost,$dbusername,$dbpassword,$dbname);
?>