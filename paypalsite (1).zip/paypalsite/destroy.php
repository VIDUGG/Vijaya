<?php 
session_start();
if(isset($_POST["empty"])){
session_destroy();

header("location:cart.php");
}
?>