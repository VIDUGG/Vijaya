<?php include("header.php");?>
    <!-- ***** Header Area End ***** -->

    <!-- ***** Main Banner Area Start ***** -->
    <div class="page-heading" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-content">
                        <h2>Shoe Store</h2>
                        <span>A COMPLETE ONE STOP SOLUTION</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->


    <!-- ***** Products Area Starts ***** -->
    <section class="section" id="products">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-heading">
                        <h2>Our Products</h2>
                        <hr>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-4">
                    <div class="item">
                        <div class="thumb">
                            <div class="hover-content">
                                <ul>
								 <li><a href="add.php?name=Jayla_High_Leg&amount=1&number=1"><i class="fa fa-shopping-cart"></i></a></li>
                                    <li><a href="one.php?name=Jayla_High_Leg&amount=1&number=1"><i class="fa fa-eye"></i></a></li>
                                   
                                </ul>
                            </div>
                            <img src="assets/images/products/1.png" alt="">
                        </div>
                        <div class="down-content">
                            <h4>Jayla High Leg</h4>
                            <span>$1.00</span>
                            
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="item">
                        <div class="thumb">
                            <div class="hover-content">
                                <ul>
								 <li><a href="add.php?name=Klara_Hiker&amount=1&number=2"><i class="fa fa-shopping-cart"></i></a></li>
                                    <li><a href="one.php?name=Klara_Hiker&amount=1&number=2"><i class="fa fa-eye"></i></a></li>
                               
                                </ul>
                            </div>
                            <img src="assets/images/products/2.png" alt="">
                        </div>
                        <div class="down-content">
                            <h4>Klara Hiker</h4>
                            <span>$1.00</span>
                           
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="item">
                        <div class="thumb">
                            <div class="hover-content">
                                <ul>
								 <li><a href="add.php?name=Kiler&amount=1&number=3"><i class="fa fa-shopping-cart"></i></a></li>
                                    <li><a href="one.php?name=Kiler&amount=1&number=3"><i class="fa fa-eye"></i></a></li>
                                   
                                </ul>
                            </div>
                            <img src="assets/images/products/3.png" alt="">
                        </div>
                        <div class="down-content">
                            <h4>Kiler</h4>
                            <span>$1.00</span>
                            
                        </div>
                    </div>
                </div>
				
				
				
				
				
				
				
				
				
				
				
				
				<div class="col-lg-4">
                    <div class="item">
                        <div class="thumb">
                            <div class="hover-content">
                                <ul>
								<li><a href="add.php?name=Men_Black_Zeta_Mesh_Running_Shoes&amount=2&number=4"><i class="fa fa-shopping-cart"></i></a></li>
                                    <li><a href="one.php?name=Men_Black_Zeta_Mesh_Running_Shoes&amount=2&number=4"><i class="fa fa-eye"></i></a></li>
                                   
                                </ul>
                            </div>
                            <img src="assets/images/products/4.png" alt="">
                        </div>
                        <div class="down-content">
                            <h4>Men Black Zeta Mesh Running Shoes</h4>
                            <span>$2.00</span>
                            
                        </div>
                    </div>
                </div>
				
				
				
				
				<div class="col-lg-4">
                    <div class="item">
                        <div class="thumb">
                            <div class="hover-content">
                                <ul>
								<li><a href="add.php?name=Men_White_Clarkin_Sneakers&amount=3&number=5"><i class="fa fa-shopping-cart"></i></a></li>
                                    <li><a href="one.php?name=Men_White_Clarkin_Sneakers&amount=3&number=5"><i class="fa fa-eye"></i></a></li>
                                   
                                </ul>
                            </div>
                            <img src="assets/images/products/5.png" alt="">
                        </div>
                        <div class="down-content">
                            <h4>Men White Clarkin Sneakers</h4>
                            <span>$3.00</span>
                            
                        </div>
                    </div>
                </div>
				
				
				
				<div class="col-lg-4">
                    <div class="item">
                        <div class="thumb">
                            <div class="hover-content">
                                <ul>
								<li><a href="add.php?name=Women_White_Mesh_High_Top_Walking_Non_-Marking_Shoes&amount=4&number=6"><i class="fa fa-shopping-cart"></i></a></li>
                                   
                                    <li><a href="one.php?name=Women_White_Mesh_High_Top_Walking_Non_-Marking_Shoes&amount=4&number=6"><i class="fa fa-eye"></i></a></li>
                                   
                                </ul>
                            </div>
                            <img src="assets/images/products/6.png" alt="">
                        </div>
                        <div class="down-content">
                            <h4>Women White Mesh High-Top Walking Non-Marking Shoes</h4>
                            <span>$4.00</span>
                            
                        </div>
                    </div>
                </div>
                
                </div>
               
            </div>
        </div>
    </section>
    <!-- ***** Products Area Ends ***** -->
    
    <!-- ***** Footer Start ***** -->
    <?php include("footer.php");?>