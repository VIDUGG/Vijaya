<?php include("header.php");?>

      <body>
	      <div class="page-heading" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-content">
                        <h2>Quick Registration & Pay Form</h2>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->


    
	   <section class="section">
        <div class="container">
            <div class="row">

	    <div class="col-lg-12">
		<div class="row">
		
		<div class="col-md-12">
		<label>
		<h5>Payable Amount: <?php echo '$'.$_GET["amount"];?></h5>
		</label>
		</div><hr>
		
		</div>
	     <form action="https://www.sandbox.paypal.com/cgi-bin/webscr"
            method="post" target="_top">
			<div class="col-md-12">
			<label>Full Name:</label><br>
			<input type="text" class="form-control" name="first_name" required>
			</div><br>
			<div class="col-md-12">
			<label>Contact Number:</label><br>
			<input type="text" class="form-control" name="night_phone_a" required>
			</div><br>
			<div class="col-md-12">
			<label>Email Id:</label><br>
			
			<input type="email" class="form-control" name="email" required></div><br>
			
            <input type='hidden' name='business' value='mounikaunt@gmail.com'> 
			<input type='hidden' name='item_name' value='shoestore'> 
			<input type='hidden' name='item_number' value='1'> 
			<input type='hidden' name='amount' value='<?php echo $_GET["amount"];?>'> 
			<input type='hidden' name='no_shipping' value='0'> 
			<input type='hidden' name='currency_code' value='USD'> 
			<input type='hidden' name='notify_url' value='https://ospmi.in/paypalsite/notify.php'>
            <input type='hidden' name='cancel_return' value='https://ospmi.in/paypalsite/cancel.php'>
            <input type='hidden' name='return' value='https://ospmi.in/paypalsite/return.php'>
            <input type="hidden" name="cmd" value="_xclick"> 
			<div class="col-md-12">
			<input type="submit" name="pay_now" id="pay_now" Value="Pay Now">
			</div>
        </form>
		
		</div>
		
       
		</div>
		</section>
<?php include("footer.php");?>