<?php 


$pdo = require_once 'config.php';
$sql= 'truncate table tblcart';
$statement = $link->prepare($sql);
$statement->execute();




header("location:index.php");
?>