<?php include("header.php");?>
    <!-- ***** Main Banner Area Start ***** -->
    <div class="page-heading" id="top">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="inner-content">
                        <h2><?php echo $_GET["name"];?></h2>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- ***** Main Banner Area End ***** -->


    <!-- ***** Product Area Starts ***** -->
    <section class="section" id="product">
        <div class="container">
            <div class="row">
                <div class="col-lg-8">
                <div class="left-images">
                    <img src=<?php echo 'assets/images/products/'.$_GET['number'].'.png';?> alt="">
                
                </div>
            </div>
            <div class="col-lg-4">
                <div class="right-content">
                    <h4><?php echo $_GET["name"];?></h4>
                    <span class="price"><?php echo "$".$_GET["amount"];?></span>
                    
                    <span>Black boots in a knee high style | Soft panel at the back of the calf | Longline inner black zip | Rounded toe and structured heel | Black low lug sole. Miss KG introduces the Jayla boots. Their knee high style contrasts with the casual low sole to provide a sought after hi-lo silhouette. Wear either dressed up or down for versatile styling. </span>
                   
                    <div class="total">
                      
                        <div class="main-border-button"><a href="buynow.php?name=<?php echo $_GET['name'];?>&amount=<?php echo $_GET['amount'];?>&number=<?php echo $_GET['number'];?>">Buy Now</a></div>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </section>
     <?php include("footer.php");?>